package ejercicio;

public class Ejercicio2 {
    
   private int n;
   private String[] cadena= new String[n];

    public int getN() {
        return this.n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public String[] getCadena() {
        return this.cadena;
    }

    public void setCadena(String[] cadena) {
        this.cadena = cadena;
    }
   
   
   
   
}
