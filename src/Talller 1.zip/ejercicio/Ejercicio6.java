package ejercicio;

public class Ejercicio6 {

    private int m;
    private int n;
    private int[][] numeros = new int[m][n];

    public int getM() {
        return this.m;
    }

    public void setM(int m) {
        this.m = m;
    }

    public int getN() {
        return this.n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public int[][] getNumeros() {
        return this.numeros;
    }

    public void setNumeros(int[][] numeros) {
        this.numeros = numeros;
    }

}
