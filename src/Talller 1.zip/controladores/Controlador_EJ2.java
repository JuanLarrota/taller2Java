package controladores;

import java.util.Scanner;
import ejercicio.Ejercicio2;
import vista.Menu;

public class Controlador_EJ2 {

    Ejercicio2 obj = new Ejercicio2();

    public void cantidad() {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese el tamanio: ");
        obj.setN(entrada.nextInt());
    }

    public void llenarArray() {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Llenar el array...");
        String cadena[] = new String[obj.getN()];
        for (int i = 0; i < obj.getN(); i++) {
            System.out.println("Ingrese el dato[" + (i + 1) + "}");
            cadena[i] = entrada.nextLine();
        }

        obj.setCadena(cadena);

    }

    public void editar() {
        Scanner numeros = new Scanner(System.in);
        Scanner letras = new Scanner(System.in);
        int inser;
        String cadenaO[] = obj.getCadena();
        String ayuda[] = cadenaO.clone();
        String palabra = "";
     
        System.out.print("Digite la posicion a insertar: ");
        inser = numeros.nextInt();
        inser -= 1;
        System.out.print("Ingrese la palabra: ");
        palabra = letras.nextLine();
        ayuda[inser] = palabra;
     
        for (int i = inser; i < obj.getN() - 1; i++) {
            ayuda[i + 1] = cadenaO[i];
        }
        
        obj.setCadena(ayuda);
    }

    public void mostrar() {

        String msg = "";
        String cadena[] = new String[obj.getN()];
        cadena = obj.getCadena();
        for (int i = 0; i < obj.getN(); i++) {
            msg += " " + cadena[i] + "\n";
        }
        System.out.println("Resultado: \n" + msg);
    }

    public void menu() {
        System.out.println("EJERCICIO 1:\n");
        cantidad();
        llenarArray();
        Scanner ent1 = new Scanner(System.in);
        int op;

        do {
            System.out.println("--------------------MENU--------------------\n");
            System.out.println("1 - Editar");
            System.out.println("2 - Mostrar");
            System.out.println("3 - Salir");

            System.out.print("Ingrese una opcion: ");
            op = ent1.nextInt();

            switch (op) {
                case 1:
                    editar();
                    break;
                case 2:
                    mostrar();
                    break;
                case 3:
                    System.out.println("Ha salido del ejercicio 2...");
                    Menu mn = new Menu();
                    mn.menu();
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        } while (op > 0 && op < 4);
    }
}
