package controladores;

import java.util.Scanner;

public class Controlador_EJ6 {
    
    
    public void tamanio(){
        Scanner numero= new Scanner(System.in);
        
        
        
        
    }
    
    
}
